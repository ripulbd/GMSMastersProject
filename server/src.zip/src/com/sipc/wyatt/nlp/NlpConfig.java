package com.sipc.wyatt.nlp;

public class NlpConfig {
	public static final int NUMOFKEYWORDS = 5;
}
