package com.sipc.wyatt.dao;

public class VarDao {
	public static final String HOST = "localhost";
	public static final int PORT = 27017;
	public static final String DBNAME = "gms";
	public static final String COLLNAME = "newsinfo";
	
	public static final String DESCRIPTION = "description";
	public static final String TITLE = "title";
	public static final String MAINSTORY = "mainStory";
}
